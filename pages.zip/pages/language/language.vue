<template>
	<view class="">
		<view class="uni-list-cell-db">
			<picker @change="bindPickerChange" :value="ind" :range="langList">
				<view class="uni-input">{{ langList[ind] }}</view>
			</picker>
		</view>
		<view class="">
			<button type="primary" @tap="go">返回</button>
		</view>
	</view>
</template>

<script>
	import lang from '../index/lang'
	export default {
		data() {
			return {
				value: '',
				langList:[],
				langType: ['cn', 'us', 'ja', 'ru'],
				ind: uni.getStorageSync('ind') || 0,
			};
		},
		computed: {
			i18n() {
				const that = this
				return lang[uni.getStorageSync('locale') || that.$i18n.locale]
			}
		},

		onShow() {
			console.log(this.$i18n.locale);
			uni.setNavigationBarTitle({
				title: lang[this.$i18n.locale].title
			});
			this.langList = lang[this.$i18n.locale].langList
		},
		methods: {
			changeLanguages() {
				const that = this;
			},
			bindPickerChange(e) {
				// this.index = e.target.value;
				this.ind = e.target.value;
				this.$i18n.locale = this.langType[this.ind];
				this.langList = this.i18n.langList
				uni.setStorageSync(
					'locale', this.langType[this.ind]
				);

				// if (e.target.value == 0) {
				// 	this.langList = ['中文', '英文', '日语', '俄语']
				// 	console.log(this.langList);
				// 	// document.getElementsByClassName('uni-picker-action-cancel')[0].innerText = '取消'
				// 	// document.getElementsByClassName('uni-picker-action-confirm')[0].innerText = '确定'
				// 	uni.setNavigationBarTitle({
				// 		title: '新的标题'
				// 	});
				// 	uni.setStorageSync(
				// 		'ind', 0
				// 	);
				// 	uni.setStorageSync('langList',this.langList);
				// } else if (e.target.value == 1) {
				// 	// document.getElementsByClassName('uni-picker-action-cancel')[0].innerText = 'cancel'
				// 	// document.getElementsByClassName('uni-picker-action-confirm')[0].innerText = 'confirm'
				// 	this.langList = ['Chinese', 'English', 'Japanese', 'Rusisa']
				// 	uni.setNavigationBarTitle({
				// 		title: 'A new title'
				// 	});
				// 	uni.setStorageSync(
				// 		'ind', 1
				// 	);
				// 	uni.setStorageSync('langList',this.langList);
				// 	console.log(this.langList);
				// } else if (e.target.value == 2) {
				// 	// document.getElementsByClassName('uni-picker-action-cancel')[0].innerText = 'キャンセル'
				// 	// document.getElementsByClassName('uni-picker-action-confirm')[0].innerText = '確定'
				// 	this.langList = ['中国语', '英語', 'フランス語', 'ロシア']
				// 	uni.setNavigationBarTitle({
				// 		title: '新しいタイトル'
				// 	});
				// 	uni.setStorageSync(
				// 		'ind', 2	
				// 	);
				// 	uni.setStorageSync(		
				// 		'langList',this.langList
				// 	);
				// 	console.log(this.langList);
				// } else {
				// 	// document.getElementsByClassName('uni-picker-action-cancel')[0].innerText = 'объявление'
				// 	// document.getElementsByClassName('uni-picker-action-confirm')[0].innerText = 'Уверен,'
				// 	this.langList = ['китайский', 'По-английски', 'японский', 'русский']
				// 	uni.setNavigationBarTitle({
				// 		title: 'Новый заголовок.'
				// 	});
				// 	uni.setStorageSync(
				// 		'ind', 3
				// 	);
				// 	uni.setStorageSync(
				// 		'langList',this.langList
				// 	);
				// 	console.log(this.langList);
				// }
			},
			go() {
				const that = this;
				uni.navigateTo({
					url: '../index/index?ind=' + that.ind
				});
			}
		}
	};
</script>

<style></style>
